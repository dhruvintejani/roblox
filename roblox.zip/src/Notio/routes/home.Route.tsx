import { BrowserRouter, Route, Routes } from "react-router-dom";
import Navbar from "../components/Navbar";
import Home from "../components/Home";
import Desc from "../components/Desc";

const HomeRoute = () => {
  return (
    <BrowserRouter>
      <Routes>
       <Route element={<Navbar />}>
          <Route index element={<Home />} />
          <Route path="/desc" element={<Desc />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
};

export default HomeRoute;

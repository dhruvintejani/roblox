import image_1 from "../../assets/Notio/n-1.jpg";
import image_2 from "../../assets/Notio/n-3.jpg";
import image_3 from "../../assets/Notio/n-4.jpg";
import image_4 from "../../assets/Notio/n-5.jpg";
import image_5 from "../../assets/Notio/n-6.jpg";
import image_6 from "../../assets/Notio/n-2.jpg";
import User_img from "../../assets/User.jpg";
import { useState } from "react";
import { Icon } from "@iconify/react";

type Message = {
  text: string;
  type: "text" | "coin";
};

const Desc = () => {
  const [formData, setFormData] = useState({ message: "" });
  const [messages, setMessages] = useState<Message[]>([]);
  const [open, setOpen] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    setFormData({ message: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (formData.message.trim() === "") return;
    setMessages((prev) => [...prev, { text: formData.message, type: "text" }]);
    setFormData({ message: "" });
  };

  const handleOpen = () => {
    setOpen(!open);
  };
  const handleCoinSubmit = () => {
    setMessages((prev) => [
      ...prev,
      { text: "Coin Sent Sucessfully", type: "coin" },
    ]);
  };

  return (
    <div className="mx-[70px] overflow-hidden pt-6">
      <div className="flex items-center animate-slide gap-[10px] w-[300px]">
        <img src={image_1} />
        <img src={image_2} />
        <img src={image_3} />
        <img src={image_4} />
        <img src={image_5} />
      </div>

      {open && (
        <div
          className={`mt-[70px] flex justify-center gap-10 ${
            open ? "animate-slideDown" : "animate-slideUp"
          }`}
        >
          <div>
            <img
              src={image_6}
              className="h-[600px] w-full rounded-3xl shadow-lg"
            />
          </div>

          <div className="w-[62%] flex flex-col bg-white rounded-3xl shadow-xl border overflow-hidden">
            <div className="flex items-center justify-between px-8 py-5 border-b bg-gradient-to-r from-blue-600 to-indigo-600">
              <div className="flex items-center gap-4">
                <img
                  src={User_img}
                  className="w-14 h-14 rounded-full border-2 border-white"
                />
                <div className="text-white">
                  <h1 className="text-xl font-semibold">User</h1>
                  <p className="text-xs opacity-80">Online</p>
                </div>
              </div>
            </div>

            <div className="flex-1 px-8 py-6 bg-gray-50 overflow-y-auto flex flex-col gap-4 max-h-[420px]">
              {messages.map((msg, index) => (
                <div
                  key={index}
                  className={`self-end tracking-wider text-[18px] px-5 py-3 rounded-2xl rounded-br-sm text-sm shadow-md ${
                    msg.type === "text"
                      ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white "
                      : "bg-yellow-400 text-black"
                  }`}
                >
                  {msg.text}
                </div>
              ))}
            </div>

            <form onSubmit={handleSubmit} className="bg-white border-t">
              <div className="flex items-center gap-4 px-6 py-4">
                <input
                  type="text"
                  placeholder="Write your message..."
                  value={formData.message}
                  onChange={handleChange}
                  className="flex-1 px-5 py-3 rounded-full border text-sm outline-none focus:ring-2 focus:ring-blue-500"
                />
                <div
                  className="px-4 py-3 cursor-pointer flex items-center gap-1 rounded-full tracking-wide bg-gradient-to-r from-blue-600 to-indigo-600 hover:bg-gradient-to-r hover:from-blue-700 hover:to-indigo-700 text-white text-sm font-semibold transition"
                  onClick={handleCoinSubmit}
                >
                  <Icon
                    className="text-yellow-400"
                    icon="mdi:bitcoin"
                    width={24}
                    height={20}
                  />
                  Send Coin
                </div>
                <button
                  type="submit"
                  className="px-8 py-3 rounded-full tracking-wide bg-gradient-to-r from-blue-600 to-indigo-600 hover:bg-gradient-to-r hover:from-blue-700 hover:to-indigo-700 text-white text-sm font-semibold transition"
                >
                  Send
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="flex justify-center p-4 my-6">
        <button
          className="px-10 py-3 rounded-full bg-gray-500 text-white font-semibold tracking-wide hover:bg-black transition"
          onClick={handleOpen}
        >
          {open ? "SHOW LESS" : "SHOW MORE"}
        </button>
      </div>
    </div>
  );
};

export default Desc;

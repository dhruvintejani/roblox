import { Link, Outlet } from "react-router-dom";
import Facebook_img from "../../assets/Group (6).png";
import TIktok_img from "../../assets/Group (7).png";
import Youtube_img from "../../assets/Group (8).png";
import Twitter_img from "../../assets/Group (9).png";
import { Icon } from "@iconify/react";

const Navbar = () => {
  return (
    <div>
      <div className="fixed top-0 left-0 w-full z-50 bg-white flex justify-between px-[72px] py-[30px]">
        <p className="text-[27px] tracking-wider">NOTIO</p>
        <div className="flex gap-11 items-center font-semibold">
          <Link to={"/"} className="hover:text-green-600">
            HOME
          </Link>
          <Link to={"/"} className="hover:text-green-600">
            PRODUCTS
          </Link>
          <div className="flex items-center">
            <Icon icon="mdi:search" width={34} />
          </div>
        </div>
      </div>

      <div className="mt-[100px]">
        <Outlet />
      </div>

      <div className="flex justify-center my-6 gap-6">
        <img
          className="hover:scale-110 transition-all duration-500"
          src={Facebook_img}
          alt=""
        />
        <img
          className="hover:scale-110 transition-all duration-500"
          src={Twitter_img}
          alt=""
        />
        <img
          className="hover:scale-110 transition-all duration-500"
          src={TIktok_img}
          alt=""
        />
        <img
          className="hover:scale-110 transition-all duration-500"
          src={Youtube_img}
          alt=""
        />
      </div>
    </div>
  );
};

export default Navbar;

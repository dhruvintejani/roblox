import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import HomePageRoute from "./Roblox/routes/Route.tsx";
import { CartProvider } from "./Roblox/context/CartContext.tsx";
import { ToastContainer } from "react-toastify";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <CartProvider>
      <ToastContainer />

      <HomePageRoute />
    </CartProvider>
  </StrictMode>
);

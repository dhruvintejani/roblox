import "./App.css";
import HomeRoute from "./Notio/routes/Notio.Route";

function App() {
  return (
    <>
      <HomeRoute/>
    </>
  );
}

export default App;

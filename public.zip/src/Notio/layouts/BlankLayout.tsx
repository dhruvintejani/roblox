import { Outlet } from "react-router-dom";

const BlankLayout = () => {
  return <Outlet />;
};

export default BlankLayout;
